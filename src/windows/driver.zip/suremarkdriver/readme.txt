README File for IBM 4610 Printer Driver for 
Windows 2000, Windows XP, Windows Server 2003 and
Windows Embedded for Point of Service

Version 2.5.0   (29 August 2008)


Contents

  - Overview
  - Software Requirements
  - Hardware Requirements
  - Printer Driver Installation
  - Configuring the Printer Driver
  - To Find the Version of the Printer Driver
  - Updating the Printer Driver
  - Removing the Printer Driver
  - Uninstalling the IBM 4610 Windows Drivers
  - Known Issues
  - Hints and Tips
  - Getting IBM Service
  - Trademarks and Copyrights



Overview

  The IBM 4610 Printer Driver supports the IBM 4610 printer when attached
  via RS-232 and USB.

  The driver supports the following version of IBM 4610 printers:

  - IBM 4610 TI3
  - IBM 4610 TI4
  - IBM 4610 TI5
  - IBM 4610 TI8
  - IBM 4610 TI9
  - IBM 4610 TM6/TF6
  - IBM 4610 TM7/TF7
  - IBM 4610 2xR


  This README file contains information that will you assist you in installing
  the printer driver.



Software Requirements

  The printer driver works with Windows 2000 Service Pack 4, Windows XP,
  Windows Server 2003 or Windows Embedded for Point of Service.



Hardware Requirements

  IBM 4610 printer, model specified above, with serial or USB interface.



Printer Driver Installation

  1. Run the printer driver package file.  For example: WXPRSENU.EXE.
  2. This will start the IBM RSS Printer Driver Wizard.  Follow the
     instructions at the top of each page of the wizard.
  3. Use the Next or Back button to forward or backward through the wizard
  4. When you are finished, select Finish.  You see the Printers folder 
     with the new printer added.


Configuring the Printer Driver

  1. Open the Printers and Faxes folder.
  2. Select the printer driver using mouse button 2.
  3. Select Properties.  You see the printer's properties notebook.
  4. Select the tab of the area you wish to edit and make the appropriate
     change.
  5. Select OK to save your changes and close the notebook.
  6. Select the printer driver using mouse button 2.
  7. Select Printing Preferences.  You see the printer's printing
     preferences notebook.
  8. Select the tab of the area you wish to edit and make the appropriate
     change.
  9. Select OK to save your changes and close the notebook.



To Find the Version of the Printer Driver

  1. From the printer's properties notebook, select the Firmware and
     Downloadable Sectors tab.
  2. Select About button.

or

  1. From the printer's printing preferences notebook, select the Setup tab.
  2. Select About button.


Updating the Printer Driver

  To update the installed printer driver with a newer version, install the new
  printer driver as described in the Printer Driver Installation section.
  The old printer driver will be overwritten with the new one.



Removing the Printer Driver

  1. Open the Printers or Printers and Faxes folder.
  2. Select the printer driver using mouse button 2.
  3. Select Delete.



Uninstalling the IBM 4610 Windows Drivers

  1.  Open the Microsoft Windows Control Panel
  2.  Select the "Add or Remove Programs" folder
  3.  Select the "IBM 4610 Native Windows Drivers"
  4.  Select "Remove"


Known Issues

  1.  After uninstalling the IBM 4610 Printer Drivers, the entry in the
      "Add or Remove Programs" is not removed and the C:\4610NWD directory
      is not removed.
  2.  On some systems the Uninstall will fail if the Microsoft MSVCP60.DLL
      is not installed.
  3.  Downloaded Japanese DBCS font does not print correctly.


Hints and Tips

  For printing documents edited using one or more of the printer's resident
  fonts, do as follows:
  1. Select the desired printer's resident font.
  2. Select one of the font sizes listed in the Font Size drop down.
  3. Edit the desired text.
  4. Print the document.

  The screen image of texts edited using printer's resident fonts may not
  always match the paper printout.

  The following applications:
    MS Power Point
    Corel Draw
  - do not load the paper sizes exported by IBM 4610 printer driver.
  - do not load the resident fonts exported by IBM 4610 printer driver.

  The following application:
    Notepad
  - does not load the resident fonts exported by IBM 4610 printer driver.

  For editing and printing barcodes in Lotus Word Pro application do as
  follows:
  1. Open Lotus Word Pro application.
  2. Select the desired barcode font.
  3. Lotus Word Pro will display an incorrect font size range: for example from
     4 to 72 logical points.
  4. Selecting the last font size (72) will change the incorrect
     font size range to the correct one.
  5. Edit the desired text using one of the displayed font sizes, except the
     last one in the font size list.
  6. Print the document.

  When the user edits text using one of the user-defined (downloaded) TrueType
  fonts, the screen image of the text may not always match the screen image of
  the same text edited using the original TrueType font.

  When the user prints documents that contain images or texts (edited using the
  TrueType fonts installed on the system), on the printed output may appear 
  some white horizontal lines.

  Some of the Windows applications don't properly refresh the fonts list while
  they running. When the user switch from Customer receipt station to Document
  insert station, the Customer receipt station resident fonts will remain in the
  application font list instead of the Document insert station resident fonts.

  When printing on Document insert station landscape mode, images are not
  allowed in the document and the allowed fonts are Font A and Font B only.

  Printing in monochrome mode using color paper in printer will result in
  printing the entire document with a specific color, depending on the used
  paper.

  Printing in 2 color mode using color paper in printer will result in printing
  the entire document with a different color than in monochrome mode printing.



Getting IBM Service

  The methods for getting IBM service for IBM 4610 printers are:

  - Technical Service:
      1-888-IBM-HELP  (1-888-426-4357)
  - WWW home page:
       http://www2.clearlake.ibm.com/store/support/index.html.


Trademarks and Copyrights

  These terms are trademarks of their respective companies in the United States
  or other countries or both:

  IBM, RSS       IBM Corporation

  Microsoft, Windows, Windows 2000, Windows XP, Windows Server 2003 and 
  Windows Embedded for Point of Service are trademarks of Microsoft Corporation
  in the United States, other countries, or both.

  Other company, product, and service names may be trademarks or service marks
  of others.


(C) Copyright IBM Corporation 2004, 2008.
All rights reserved.


