/********************************************************************/
/*                                                                  */
/*  Licensed Materials - Property of IBM                            */
/*                                                                  */
/*  IBM Native Microsoft Windows Drivers                            */
/*  (C) Copyright IBM Corporation 2004, 2008                        */
/*  All rights reserved                                             */
/*                                                                  */
/*  US Government Users Restricted Rights -                         */
/*  Use, duplication, or disclosure restricted                      */
/*  by GSA ADP Schedule Contract with IBM Corp.                     */
/*                                                                  */
/********************************************************************/


#ifndef IBM4610API_H
#define IBM4610API_H

#ifndef STATUS_CALLBACK
#define STATUS_CALLBACK

typedef int (CALLBACK* StatusCallback)(DWORD);

#endif


// IBM 4610 API open types
#define TYPE_PORT                       1 // use port name
#define TYPE_PRINTER                    2 // use printer driver name


// IBM 4610 API return codes
#ifndef SUCCESS
#define SUCCESS                         0 // Success
#endif
#define ERR_TYPE                      -10 // nType error
#define ERR_OPENED                    -20 // Already opened
#define ERR_NO_PRINTER                -30 // There is not printer driver
#define ERR_NO_TARGET                 -40 // Printer out of object
#define ERR_NO_MEMORY                 -50 // No memory
#define ERR_HANDLE                    -60 // Invalid handle
#define ERR_TIMEOUT                   -70 // Ttime out
#define ERR_ACCESS                    -80 // cannot read/write
#define ERR_PARAM                     -90 // param error
#define ERR_NOT_SUPPORT              -100 // not support
#define ERR_OFFLINE                  -110 // now offline
#define ERR_NOT_EPSON                -120 // not epson printer
#define ERR_WITHOUT_CB               -130 // without callback function
#define ERR_BUFFER_OVER_FLOW         -140 // Read buffer over flow
#define ERR_REGISTRY                 -150 // Regstry error
#define ERR_ENABLE                   -160 // BiOpenMonPrinter() is already called
#define ERR_DISK_FULL                -170 // Capacity of a disk is insufficient
#define ERR_NO_IMAGE                 -180 // No image data
#define ERR_ENTRY_OVER               -190 // Registration number-of-cases over
#define ERR_CROPAREAID               -200 // No specific CropAreaID
#define ERR_EXIST                    -210 // Already the same thing
#define ERR_NOT_FOUND                -220 // Not found
#define ERR_IMAGE_FILEOPEN           -230 // Open failure
#define ERR_IMAGE_UNKNOWNFORMAT      -240 // Format injustice
#define ERR_IMAGE_FAILED             -250 // Image creation failure
#define ERR_WORKAREA_NO_MEMORY       -260 // No memory for WORKAREA
#define ERR_WORKAREA_UNKNOWNFORMAT   -270 // Image creation failure because of
                                          // format injustice
#define ERR_WORKAREA_FAILED          -280 // WORKAREA creation failure
#define ERR_PRINTER_OPERATION        -290 // Printer operation error


// IBM 4610 API statuses that can be acquired
#define ASB_NO_RESPONSE                 0x00000001 //No response
#define ASB_PRINT_SUCCESS               0x00000002 //Finish to print
#define ASB_UNRECOVER_ERR               0x00002000 //Unrecoverable error
#define ASB_AUTORECOVER_ERR             0x00004000 //Auto-Recoverable error
#define ASB_OFF_LINE                    0x00000008 //Off-line
#define ASB_PRINTER_FEED                0x00000040 //Paper is being fed by using
                                                   // the PAPER FEED button
#define ASB_PANEL_SWITCH                0x00000200 //Panel switch
#define ASB_MECHANICAL_ERR              0x00000400 //Mechanical error
#define ASB_AUTOCUTTER_ERR              0x00000800 //Auto cutter error
#define ASB_DRAWER_KICK                 0x00000004 //Drawer kick-out connector
                                                   // pin3 is HIGH
#define ASB_RECEIPT_END                 0x00080000 //Receipt paper roll end
#define ASB_COVER_OPEN                  0x00000020 //Cover is open
#define ASB_RECEIPT_NEAR_END            0x00020000 //Receipt paper roll near-end
#define ASB_SLIP_TOF                    0x00200000 //SLIP TOF
#define ASB_SLIP_BOF                    0x00400000 //SLIP BOF
#define ASB_SLIP_SELECTED               0x01000000 //Slip is not selected
#define ASB_PRINT_SLIP                  0x02000000 //Cannot print on slip
#define ASB_VALIDATION_SELECTED         0x04000000 //Validation is not selected
#define ASB_PRINT_VALIDATION            0x08000000 //Cannot print on validation
#define ASB_VALIDATION_TOF              0x20000000 //Validation TOF
#define ASB_VALIDATION_BOF              0x40000000 //Validation BOF



// IBM 4610 API cash drawer related defines
#define EPS_BI_DRAWER_1                 1
#define EPS_BI_DRAWER_2                 2
#define EPS_BI_PULSE_100                1
#define EPS_BI_PULSE_200                2
#define EPS_BI_PULSE_300                3
#define EPS_BI_PULSE_400                4
#define EPS_BI_PULSE_500                5
#define EPS_BI_PULSE_600                6
#define EPS_BI_PULSE_700                7
#define EPS_BI_PULSE_800                8



// IBM 4610 API MICR read detailed information
#define MICRREAD_DET_NO_ABNORMALITY     0x40      // No abnormality
#define MICRREAD_DET_NO_MICR_EXECUTED   0x41      // Check reading was not
                                                  // executed even once
                                                  // (The BiMICRREADCheck
                                                  // function has not been
                                                  // called)
#define MICRREAD_DET_INSERT_CANCELED    0x42      // Check insertion wait was
                                                  // canceled (The
                                                  // BiMICRCancelWaitCheckInsertion
                                                  // function was called)
#define MICRREAD_DET_TIMEOUT            0x43      // Check insertion wait was
                                                  // canceled by the set time
                                                  // being exceeded (The time
                                                  // out set time passed while
                                                  // the BiMICRReadCheckfunction
                                                  // was being called)
#define MICRREAD_DET_NO_STD_LENGTH      0x44      // A check with a non-standard
                                                  // length was inserted
#define MICRREAD_DET_NO_DETECTED        0x45      // The magnetic waveform was
                                                  // not detected
#define MICRREAD_DET_UNREADABLE_CHAR    0x46      // Characters which could not
                                                  // be analyzed were detected
                                                  // in analysis processing
#define MICRREAD_DET_ERROR_READING      0x47      // An error occurred during
                                                  // check reading processing
#define MICRREAD_DET_ERROR_NOISE        0x48      // An error was detected in
                                                  // the noise measurement
#define MICRREAD_DET_COVER_OPENED       0x49      // Check reading processing
                                                  // was interrupted by the
                                                  // cover being opened



// IBM 4610 API image format
#define EPS_BI_SCN_TIFF                 1         // TIFF format compressed data
                                                  // (TIFF-CCIT compression)
#define EPS_BI_SCN_RASTER               2         // Raster format uncompressed
                                                  // data (No compression (gray
                                                  // scale))
#define EPS_BI_SCN_BITMAP               3         // Bitmap format uncompressed
                                                  // data (BMP (uncompressed))
#define EPS_BI_SCN_TIFF256              4         // TIFF format uncompressed
                                                  // data (TIFF File no
                                                  // compression)
#define EPS_BI_SCN_JPEGNORMAL           6         // JPEG format normal
                                                  // compression data (JPEG
                                                  // compression)


// IBM 4610 API SCN status
#define SCNREAD_STATUS_ERROR            0x20      // Scanning ended with an
                                                  // error


// IBM 4610 API SCN read detailed information
#define SCNREAD_DET_NO_ERROR            0x40      // No error
#define SCNREAD_DET_SCAN_RES_NOT_EXIST  0x41      // The image scanning result
                                                  // does not exist
#define SCNREAD_DET_SCAN_INTERRUPTED    0x44      // The cover was opened, so
                                                  // image scanning was
                                                  // interrupted
#define SCNREAD_DET_COMPRESSION_ERROR   0x47      // Compressed data error (The
                                                  // amount of data increased
                                                  // in data compression
                                                  // processing, and there was
                                                  // insufficient memory.)
#define SCNREAD_DET_FEED_ERROR          0x48      // Paper insertion status or
                                                  // paper feed error
#define SCNREAD_DET_LACK_MEM_SAVING     0x60      // Lack of remaining capacity
                                                  // in NV memory for saving
                                                  // reading result of images
#define SCNREAD_DET_LACK_MEM_WRITING    0x61      // Failure of writing process
                                                  // of reading result of
                                                  // images to the NV memory



/*******************************************************************************
// IBM 4610 API exported function prototypes                                  //
*******************************************************************************/

int WINAPI BiOpenMonPrinter(int   nType,    // This specifies the type of name
                                            // specified in pName.  One of the
                                            // following two types is specified:
                                            // TYPE_PORT     The port name is
                                            //               specified in pName
                                            // TYPE_PRINTER  The printer name is
                                            //               specified in pName
                            LPSTR pName);   // This specifies the printer that
                                            // is opened


int WINAPI BiCloseMonPrinter(int nHandle);  // This specifies the handle value
                                            // of the printer to be closed.
                                            // The value returned from
                                            // BiOpenMonPrinter() is used as
                                            // the handle value


int WINAPI BiGetType(int    nHandle,        // Specifies the handle value of
                                            // the printer being accessed.
                                            // The BiOpenMonPrinter() return
                                            // value is used in the handle value
                     LPBYTE typeID,         // Sets the printer's type ID
                                            // (refer to the list of type IDs)
                     LPBYTE font,           // Sets the font mounted on the
                                            // printer (refer to the list of
                                            // installed fonts)
                                            // (Not supported)
                     LPBYTE exrom,          // Sets the capacity of the printer
                                            // expanded flash ROM
                     LPBYTE euspecial);     // Sets the printer.s type ID(B)


int WINAPI BiGetStatus(int     nHandle,     // Specify the handle value of the
                                            // printer you are acquiring the
                                            // status of. For the handle value,
                                            // use the value returned by
                                            // BiOpenMonPrinter()
                       LPDWORD lpStatus);   // The current status of the
                                            // printer is set


int WINAPI BiGetOfflineCode(int    nHandle, // Specifies the handle value of
                                            // the printer being accessed.
                                            // The BiOpenMonPrinter() return
                                            // value is used in the handle value
                            LPBYTE offlinecode); // Sets the bit that indicates
                                                 // the reason for being
                                                 // off-line


int WINAPI BiCancelError(int nHandle);      // Specifies the handle value of
                                            // the printer being accessed
                                            // The BiOpenMonPrinter() return
                                            // value is used in the handle value


int WINAPI BiOpenDrawer(int  nHandle,       // Specifies the handle value of
                                            // the printer executing the
                                            // function.  The return value in
                                            // BiOpenMonPrinter() is specified
                        BYTE drawer,        // Specifies the drawer to be opened
                                            // EPS_BI_DRAWER_1:  Operates
                                            //                   Drawer 1
                                            // EPS_BI_DRAWER_2:  Operates
                                            //                   Drawer 2
                        BYTE pulse);        // Specifies the interval until
                                            // drawer operation:
                                            // EPS_BI_PULSE_100:  Operates the
                                            //                    drawer after
                                            //                    100 msec
                                            // EPS_BI_PULSE_200:  Operates the
                                            //                    drawer after
                                            //                    200 msec
                                            // EPS_BI_PULSE_300:  Operates the
                                            //                    drawer after
                                            //                    300 msec
                                            // EPS_BI_PULSE_400:  Operates the
                                            //                    drawer after
                                            //                    400 msec
                                            // EPS_BI_PULSE_500:  Operates the
                                            //                    drawer after
                                            //                    500 msec
                                            // EPS_BI_PULSE_600:  Operates the
                                            //                    drawer after
                                            //                    600 msec
                                            // EPS_BI_PULSE_700:  Operates the
                                            //                    drawer after
                                            //                    700 msec
                                            // EPS_BI_PULSE_800:  Operates the
                                            //                    drawer after
                                            //                    800 msec


int WINAPI BiSetMonInterval(int  nHandle,   // Specifies the handle value of
                                            // the printer to change the
                                            // interval
                                            // The BiOpenMonPrinter() return
                                            // value is used in the handle value
                            WORD wNoPrnInterval,    // Specifies the interval
                                                    // to get information from
                                                    // the printer expressed in
                                                    // milliseconds during
                                                    // non-printing
                            WORD wPrnInterval);     // Specified the interval
                                                    // to get information from
                                                    // the printer expressed in
                                                    // milliseconds during
                                                    // printing


int WINAPI BiSetStatusBackFunction(int  nHandle,    // This specifies the handle
                                                    // value of the printer for
                                                    // which the status is
                                                    // monitored.  The
                                                    // BiOpenMonPrinter()
                                                    // return value is used as
                                                    // the handle value
                                   int (CALLBACK *pStatusCB)(DWORD dwStatus));
                                                    // Sets the callback
                                                    // function.s address


int WINAPI BiCancelStatusBack(int nHandle); // Specifies the handle value for
                                            // the printer for which Automatic
                                            // Status Back is being canceled.
                                            // The value returned from
                                            // BiOpenMonPrinter() is used as
                                            // the handle value


int WINAPI BiMICRSetReadBackFunction(int    nHandle, // Specifies the handle
                                                     // value of the executing
                                                     // printer.  The return
                                                     // value specified in
                                                     // BiOPENMonPRinter() is
                                                     // specified as the handle
                                                     // value
                                     int    (CALLBACK *pMicrCB)(void),
                                                     // Specifies the address
                                                     // of the callback function
                                                     // for notifying the
                                                     // results from reading of
                                                     // a check
                                     LPBYTE pReadBuffSize,   // Specifies the
                                                             // size of the
                                                             // memory where
                                                             // the reading data
                                                             // are set.  After
                                                             // execution of
                                                             // this function,
                                                             // the size of the
                                                             // data which were
                                                             // actually read
                                                             // is set
                                     LPBYTE readCharBuff,    // Specifies the
                                                             // memory address
                                                             // where the check
                                                             // reading data
                                                             // are set
                                     LPBYTE pStatus,         // Specifies a
                                                             // 1-byte memory
                                                             // address where
                                                             // the reading
                                                             // status is stored
                                     LPBYTE pDetail);        // Specifies a
                                                             // 1-byte memory
                                                             // address in which
                                                             // reading of a
                                                             // check ends in
                                                             // an error, which
                                                             // is returned in
                                                             // cases where
                                                             // detailed
                                                             // information is
                                                             // added in
                                                             // accordance with
                                                             // theBiMICRSelectDataHandlingfunction


int WINAPI BiMICRSelectDataHandling(int  nHandle,  // Specifies the handle value
                                                   // of the printer executing
                                                   // the function
                                                   // The return value in
                                                   // BiOpenMonPrinter() is
                                                   // specified
                                    BYTE charSelect, // Specifies handling of
                                                     // characters that cannot
                                                     // be analyzed:
                                                     // 0:  Interrupts analysis
                                                     //     processing at the
                                                     //     point when
                                                     //     characters that
                                                     //     cannot be analyzed
                                                     //     are detected and
                                                     //     doesn't add the
                                                     //     reading data
                                                     // 1:  Replaces characters
                                                     //     which cannot be
                                                     //     analyzed with a .?.
                                                     //     and continues
                                                     //     analysis processing,
                                                     //     then if the reading
                                                     //     data size is at or
                                                     //     less than the
                                                     //     reading data size
                                                     //     specified in
                                                     //     BiMICRSetReadBackFunction,
                                                     //     the reading data
                                                     //     are added
                                    BYTE detailSelect,  // Specifies whether or
                                                        // not to add detailed
                                                        // information after a
                                                        // reading error:
                                                        // 0:  Detailed
                                                        //     information is
                                                        //     not added
                                                        // 1:  Detailed
                                                        //     information is
                                                        //     added
                                                        // (Not supported)
                                    BYTE errorSelect);  // Specifies whether or
                                                        // not to end the MICR
                                                        // function or continue
                                                        // it after an error.
                                                        // Furthermore, the
                                                        // MICR function
                                                        // continues regardless
                                                        // of this setting if
                                                        // reading ends normally
                                                        // or if there was an
                                                        // error in adding the
                                                        // reading results:
                                                        // 0:  The MICR function
                                                        //     is ended only
                                                        //     after there is
                                                        //     an error in not
                                                        //     adding the
                                                        //     reading data
                                                        // 1:  If reading ends
                                                        //     due to an error
                                                        //     caused by any of
                                                        //     the following
                                                        //     causes, the MICR
                                                        //     function continues
                                                        //     even after
                                                        //     notification of
                                                        //     the reading
                                                        //     results
                                                        // (Not supported)


int WINAPI BiMICRReadCheck(int  nHandle,    // Specifies the handle value of the
                                            // printer executing the function
                                            // The return value in
                                            // BiOpenMonPrinter() is specified
                           BYTE readFont,   // Specifies the reading font
                                            // 0:  E13B
                                            // 1:  CMC7
                                            // (Not supported)
                           BYTE waitInsertionTime); // Specifies the check
                                                    // insertion wait time
                                                    // 0 ~ 15 (x 60 sec.)
                                                    // (The printer's default
                                                    // is 0)


int WINAPI BiMICRRetransmissionCheckData(int    nHandle, // Specifies the handle
                                                         // value of the printer
                                                         // executing the
                                                         // function
                                                         // The return value in
                                                         // BiOpenMonPrinter()
                                                         // is specified
                                         LPBYTE pReadBuffSize, // Specifies the
                                                               // size of memory
                                                               // where the
                                                               // reading data
                                                               // are set
                                                               // After this
                                                               // function is
                                                               // executed, the
                                                               // size of the
                                                               // actual reading
                                                               // data is set
                                         LPBYTE readCharBuff,  // Specifies the
                                                               // memory
                                                               // addresses
                                                               // where the
                                                               // reading data
                                                               // are set
                                         LPBYTE pStatus,       // Specifies a
                                                               // 1-byte memory
                                                               // address where
                                                               // the reading
                                                               // status is set
                                                               // (Not supported)
                                         LPBYTE pDetail,       // Specifies a
                                                               // 1-byte memory
                                                               // address that
                                                               // sets detailed
                                                               // information
                                                               // after a
                                                               // returned
                                                               // reading error
                                                               // (Not supported)
                                         DWORD  timeout);      // Specifies the
                                                               // time-out time
                                                               // for data
                                                               // reading in
                                                               // msec units


int WINAPI BiMICRLoadCheck(int nHandle);    // Specifies the handle value of
                                            // the printer executing the
                                            // function.  The return value in
                                            // BiOpenMonPrinter() is specified


int WINAPI BiMICRGetStatus(int    nHandle,  // Specifies the handle value of the
                                            // printer executing the function
                                            // The return value in
                                            // BiOpenMonPrinter() is specified
                           LPBYTE pStatus); // Specifies the memory address
                                            // where the MICR status is set
                                            // See the following MICR states
                                            // concerning the types of MICR
                                            // status that are returned


int WINAPI BiMICREjectCheck(int nHandle);   // Specifies the handle value of the
                                            // printer executing the function
                                            // The return value in
                                            // BiOpenMonPrinter() is specified


int WINAPI BiMICRCancelWaitCheckInsertion(int nHandle);  // Specifies the handle
                                                         // value of the printer
                                                         // executing the
                                                         // function
                                                         // The return value in
                                                         // BiOpenMonPrinter()
                                                         // is specified


int WINAPI BiMICRCancelReadBack(int nHandle);   // Specifies the handle value
                                                // of the printer executing the
                                                // function
                                                // The return value in
                                                // BiOpenMonPrinter() is
                                                // specified


// Exported functions that return SUCCESS
int WINAPI BiSetDefaultEchoTime(BYTE Count,
                                WORD Timeout);

int WINAPI BiSetEtherEchoTime(int  nHandle,
                              BYTE Count,
                              WORD Timeout);


// Exported functions that return ERR_NOT_EPSON
int WINAPI BiDirectIO(int    nHandle,
                      BYTE   writeLen,
                      LPBYTE writeCmd,
                      LPBYTE readLen,
                      LPBYTE readBuff,
                      DWORD  timeout,
                      BOOL   nullTerminate);


int WINAPI BiDirectIOEx(int     nHandle,
                        DWORD   writeLen,
                        LPBYTE  writeCmd,
                        LPDWORD readLen,
                        LPBYTE  readBuff,
                        DWORD   timeout,
                        BOOL    nullTerminate,
                        BYTE    option);


// Exported functions that return ERR_NOT_SUPPORT
int WINAPI BiResetPrinter(int nHandle);

int WINAPI BiGetCounter(int     nHandle,
                        BYTE    readno,
                        LPDWORD readcounter);

int WINAPI BiResetCounter(int  nHandle,
                          BYTE writeno);

int WINAPI BiGetInkStatus(int     nHandle,
                          LPDWORD Status);

int WINAPI BiSetInkStatusBackFunction(int nHandle,
                                      int (CALLBACK *pStatusCB)(DWORD dwStatus));

int WINAPI BiSetInkStatusBackWnd(int     nHandle,
                                 long    hWnd,
                                 LPDWORD lpdwStatus);

int WINAPI BiCancelInkStatusBack(int nHandle);

int WINAPI BiMICRSetReadBackWnd(int    nHandle,
                                long   hWnd,
                                LPBYTE pReadBuffSize,
                                LPBYTE readCharBuff,
                                LPBYTE pStatus,
                                LPBYTE pDetail);

int WINAPI BiMICRCleaning(int nHandle);

int WINAPI BiSCNSetImageQuality(int  nHandle,
                                BYTE bColorDepth,
                                char bThreshold,
                                BYTE bColor,
                                BYTE bExOption);

int WINAPI BiSCNSetImageFormat(int  nHandle,
                               BYTE bFormat);

int WINAPI BiSCNSetScanArea(int  nHandle,
                            BYTE bStartX,
                            BYTE bStartY,
                            BYTE bEndX,
                            BYTE bEndY);

int WINAPI BiSCNPreScan(int    nHandle,
                        LPBYTE pResultStatus,
                        char*  pThreshold);

int WINAPI BiSCNGetImageQuality(int    nHandle,
                                LPBYTE pColorDepth,
                                char*  pThreshold,
                                LPBYTE pColor,
                                LPBYTE pExOption);

int WINAPI BiSCNGetImageFormat(int    nHandle,
                               LPBYTE pFormat);

int WINAPI BiSCNGetScanArea(int    nHandle,
                            LPBYTE pStartX,
                            LPBYTE pStartY,
                            LPBYTE pEndX,
                            LPBYTE pEndY);

int WINAPI BiSCNSetReadBackFunction(int     nHandle,
                                    int     (CALLBACK *pScnCB)(void),
                                    LPDWORD pBuffSize,
                                    LPBYTE* pBuff,
                                    LPBYTE  pImageXsize,
                                    LPBYTE  pStatus,
                                    LPBYTE  pDetail);

int WINAPI BiSCNSetReadBackWnd(int     nHandle,
                               long    hWnd,
                               LPDWORD pBuffSize,
                               LPBYTE  pBuff,
                               LPBYTE  pImageXsize,
                               LPBYTE  pStatus,
                               LPBYTE  pDetail);

int WINAPI BiSCNCancelReadBack(int nHandle);

int WINAPI BiSCNReadImage(int    nHandle,
                          WORD   wId,
                          BYTE   bSelectSheet,
                          BYTE   bWaitInsertionTime,
                          BYTE   bAddInforDataSize,
                          LPBYTE pAddInforData,
                          BYTE   bMemory);

int WINAPI BiSCNRetransmissionImage(int     nHandle,
                                    WORD    wId,
                                    LPDWORD pBuffSize,
                                    LPBYTE* pBuff,
                                    LPBYTE  pImageXsize,
                                    LPBYTE  pStatus,
                                    LPBYTE  pDetail,
                                    DWORD   dwTimeout);

int WINAPI BiSCNGetClumpStatus(int    nHandle,
                               LPBYTE pStatus);

int WINAPI BiSCNClumpPaper(int nHandle);

int WINAPI BiSCNSetCroppingArea(int  nHandle,
                                BYTE bAreaNo,
                                BYTE bStartX,
                                BYTE bStartY,
                                BYTE bEndX,
                                BYTE bEndY);

int WINAPI BiSCNGetCroppingArea(int    nHandle,
                                LPWORD pBuffSize,
                                LPBYTE pBuff);

int WINAPI BiSCNDeleteCroppingArea(int  nHandle,
                                   BYTE AreaNo);

int WINAPI BiSCNDeleteImage(int  nHandle,
                            WORD wID);

int WINAPI BiSCNGetImageList(int    nHandle,
                             LPWORD pListNum,
                             LPWORD pIDList);

int WINAPI BiSCNGetImageRemainingCapacity(int     nHandle,
                                          LPDWORD pSize);

int WINAPI BiESCNEnable(BYTE bStoreType);

int WINAPI BiESCNGetAutoSize(int    nHandle,
                             LPBYTE pCapAutoSize);

int WINAPI BiESCNSetAutoSize(int  nHandle,
                             BYTE bCapAutoSize);

int WINAPI BiESCNGetCutSize(int    nHandle,
                            LPWORD pCutSize);

int WINAPI BiESCNSetCutSize(int  nHandle,
                            WORD wCutSize);

int WINAPI BiESCNGetRotate(int    nHandle,
                           LPBYTE pCapRotate);

int WINAPI BiESCNSetRotate(int  nHandle,
                           BYTE bCapRotate);

int WINAPI BiESCNGetDocumentSize(int    nHandle,
                                 LPWORD pDocumentWidth,
                                 LPWORD pDocumentHeight);

int WINAPI BiESCNSetDocumentSize(int  nHandle,
                                 WORD wDocumentWidth,
                                 WORD wDocumentHeight);

int WINAPI BiESCNDefineCropArea(int  nHandle,
                                BYTE bCropAreaID,
                                WORD wStartX,
                                WORD wStartY,
                                WORD wEndX,
                                WORD wEndY);

int WINAPI BiESCNGetMaxCropAreas(int    nHandle,
                                 LPBYTE pMaxCropAreas);

int WINAPI BiESCNStoreImage(int     nHandle,
                            LPDWORD lpdwFileIndex,
                            LPSTR   pFileID,
                            LPSTR   pImageTagData,
                            BYTE    bCropAreaID);

int WINAPI BiESCNRetrieveImage(int     nHandle,
                               DWORD   dwFileIndex,
                               LPSTR   pFileID,
                               LPSTR   pImageTagData,
                               LPDWORD pImageSize,
                               LPBYTE* pImageData);

int WINAPI BiESCNClearImage(int   nHandle,
                            BYTE  bFlag,
                            DWORD dwFileIndex,
                            LPSTR pFileID,
                            LPSTR pImageTagData);

int WINAPI BiESCNGetRemainingImages(int    nHandle,
                                    LPBYTE pRemainingImages);

int WINAPI BiGetPrnCapability(int    nHandle,
                              BYTE   prnID,
                              LPBYTE pBuffSize,
                              LPBYTE pBuff);

int WINAPI BiSetMonEtherInterval(int  nHandle,
                                 WORD wEtherInterval);

int WINAPI Config4610PrinterDriver(char*  sPrinterName,
                                   LPVOID lpSettings);

int WINAPI DownloadLogo(char*  sPrinterName,
                        LPVOID lpLogos);

int WINAPI DownloadMessage(char*  sPrinterName,
                           LPVOID lpMessages);

int WINAPI DownloadFont(char*  sPrinterName,
                        LPVOID lpFonts);

int WINAPI DownloadDBCSFont(char*  sPrinterName,
                            LPVOID lpFonts);

int WINAPI UpdatePrinterFirmware(char* sPrinterName,
                                 char* sFirmwareFilePath);

void GetPrinterName(LPTSTR szPrinterName,
                    LPTSTR szPortName);

#endif
